create function users_todos_list(users bigint) returns text
    language plpgsql
as
$$
begin
        return array_to_json(array(select row_to_json(row, true)
                                   from (select * from todo.todo t where not t.is_deleted and t.created_by = userid) row))::text;
    end
$$;

alter function users_todos_list(bigint) owner to postgres;

